package it.unibs.arnaldo.CodiceFiscale;

public class Persona {

	private String nome;
	private String cognome;
	private char sesso;
	private String comuneNascita;
	private String dataNascita;
	private String codiceFiscale;
	
	public Persona(String nome, String cognome, char sesso, String comuneNascita, String dataNascita) {
		super();
		this.nome = nome;
		this.cognome = cognome;
		this.sesso = sesso;
		this.comuneNascita = comuneNascita;
		this.dataNascita = dataNascita;
	}

	public String getCodiceFiscale() {
		return codiceFiscale;
	}

	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}

	public String getNome() {
		return nome;
	}

	public String getCognome() {
		return cognome;
	}

	public char getSesso() {
		return sesso;
	}

	public String getComuneNascita() {
		return comuneNascita;
	}

	public String getDataNascita() {
		return dataNascita;
	}
	
	
	
}
