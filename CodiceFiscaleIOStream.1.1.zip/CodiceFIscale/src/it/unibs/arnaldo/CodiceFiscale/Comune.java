package it.unibs.arnaldo.CodiceFiscale;

public class Comune {

	private String nomeComune;
	private String codice;
	public Comune(String nomeComune, String codice) {
		super();
		this.nomeComune = nomeComune;
		this.codice = codice;
	}
	
	
}
