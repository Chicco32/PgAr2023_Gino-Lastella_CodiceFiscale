package it.unibs.arnaldo.CodiceFiscale;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.xml.stream.*;

public class IOStream {

	private ArrayList <String> listaCodici;
	private ArrayList <Comune> listaComuni;
	private ArrayList <Persona> listaPersone;
	public final String nomeCodici = "CodiciFiscali.xml";
	public final String nomeComuni = "Comuni.xml";
	public final String nomePersone = "InputPersone.xml";
	public final String nomeOutput = "CodiciPersone.xml";
	public final String path = "/CodiceFIscale/src/it/unibs/arnaldo/CodiceFiscale";
	
	/*
	 * questo è il costruttore, non richiede parametri in ingresso e quando viene invocato avvia le procedure di lettura da file
	 */
	public IOStream() throws XMLStreamException, FileNotFoundException {
		this.listaCodici = this.setListaCodici();
		this.listaComuni = this.setListaComuni();
		this.listaPersone = this.setListaPersone();
	}
	
	/**
	 * Questo metodo aggiorna la lista dei codici fiscali e restituisce al costruttore l'ArrayList di stringhe
	 */
	private ArrayList<String> setListaCodici() {
			try {
				this.leggiListaCodiciFiscali();
			} catch (FileNotFoundException e) {
				System.out.println("File non trovato");
				e.printStackTrace();
			} catch (XMLStreamException e) {
				System.out.println("problemi nello stream");
				e.printStackTrace();
			}
		return listaCodici;
	}
	
	/**
	 * Questo metodo aggiorna la lista dei comuni fiscali e restituisce al costruttore l'ArrayList di comuni (nome,codice)
	 */
	private ArrayList<Comune> setListaComuni() throws FileNotFoundException {
		try {
			this.leggiListaComuni();
		}
		catch (Exception e) {
			System.out.println("File non trovato");
		}
		return listaComuni;
	}

	/**
	 * Questo metodo aggiorna la lista dei codici fiscali e restituisce al costruttore l'ArrayList di persone (nome, cognome, sesso, comuneNascita, dataNascita)
	 */
	private ArrayList<Persona> setListaPersone() throws FileNotFoundException {
		try {
			this.leggiListaPersone();
		}
		catch (Exception e) {
			System.out.println("File non trovato");
		}
		return listaPersone;
	}
	
	/**
	 * 
	 * @return la lista dei codici fiscali come stringhe
	 */
	public ArrayList<String> getListaCodici() {
		return listaCodici;
	}

	/**
	 * 
	 * @return la lista dei comuni come oggetot Comune
	 */
	public ArrayList<Comune> getListaComuni() {
		return listaComuni;
	}
	/**
	 * 
	 * @return la lista delle persone come Oggetto persona
	 */

	public ArrayList<Persona> getListaPersone() {
		return listaPersone;
	}
	
	/**
	 * @user la funzione di output prevede la necessita degli array di spaiati e invalidi separati, nonchè la lista aggiornata di utenti con i loro codici fiscali
	 */
	public void scriviOutput (ArrayList <Persona> listaPersoneoutput, ArrayList <String> codiciInvalidi, ArrayList <String> codiciSpaiati) throws XMLStreamException {
		XMLStreamWriter xmlw = inizializzaWriter(nomeOutput);
		try {
		//per chiarezza uso l'indentazione tra i metodi di apertura e chiususra tag, gli attributi sulla stessa riga delle aperture
		xmlw.writeStartElement("output"); //apre la root
		
			//inizia con la parte di persone 
			xmlw.writeStartElement("persone"); xmlw.writeAttribute("numero", Integer.toString(listaPersoneoutput.size()));
			//per ogni elemento persona deve creare tutti i suoi sottoelementi
			for (int i=0; i<listaPersoneoutput.size(); i++) {
				xmlw.writeStartElement("persona"); xmlw.writeAttribute("ID", Integer.toString(i));
					stampaSottoElemento(xmlw, "nome", listaPersoneoutput.get(i).getNome());
					stampaSottoElemento(xmlw, "cognome", listaPersoneoutput.get(i).getCognome());
					stampaSottoElemento(xmlw, "sesso", Character.toString(listaPersoneoutput.get(i).getSesso()));
					stampaSottoElemento(xmlw, "comune_nascita", listaPersoneoutput.get(i).getComuneNascita());
					stampaSottoElemento(xmlw, "data_nascita", listaPersoneoutput.get(i).getDataNascita());
					stampaSottoElemento(xmlw, "codice_fiscale", listaPersoneoutput.get(i).getCodiceFiscale());
				xmlw.writeEndElement(); //chiude persona
			}
			xmlw.writeEndElement(); //chiude persone
			
			//inizia la parte di codici
			xmlw.writeStartElement("codici");
				stampaCicloDiCodici(codiciInvalidi, xmlw, "invalidi");
				stampaCicloDiCodici(codiciSpaiati, xmlw, "spaiati");
			xmlw.writeEndElement(); //chiude codici
			
		xmlw.writeEndElement();//chiude la root
		xmlw.writeEndDocument(); 
		xmlw.flush();
		xmlw.close();
		}
		catch (Exception e) { // se c’è un errore viene eseguita questa parte
		System.out.println("Errore nella scrittura");
		}
	}

	private void stampaSottoElemento(XMLStreamWriter xmlw, String nomeSottoElemento, String valoreDaStampare)
			throws XMLStreamException {
		xmlw.writeStartElement(nomeSottoElemento);
			xmlw.writeCharacters(valoreDaStampare);
		xmlw.writeEndElement();
	}

	private void stampaCicloDiCodici(ArrayList<String> codici, XMLStreamWriter xmlw, String titolo) throws XMLStreamException {	
		xmlw.writeStartElement(titolo); xmlw.writeAttribute("numero", Integer.toString(codici.size()));
			for (int i=0; i<codici.size(); i++) {
				xmlw.writeStartElement("codice");
					xmlw.writeCharacters(codici.get(i));
				xmlw.writeEndElement();
			}
		xmlw.writeEndElement();
	}
	
	private XMLStreamReader inizializzaReader(String percorsofile, FileInputStream filestream) throws FactoryConfigurationError {
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		try {
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader(percorsofile, filestream);
			}
		catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
			}
		return xmlr;
	}
	
	private XMLStreamWriter inizializzaWriter(String nomeOutput) throws FactoryConfigurationError {
		XMLOutputFactory xmlof = null;
		XMLStreamWriter xmlw = null;
		try {
			xmlof = XMLOutputFactory.newInstance();
			xmlw = xmlof.createXMLStreamWriter(new FileOutputStream(nomeOutput), "utf-8");
			xmlw.writeStartDocument("utf-8", "1.0");
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del writer:");
			System.out.println(e.getMessage());
		}
		return xmlw;
	}
	
	private void leggiListaCodiciFiscali () throws XMLStreamException, FileNotFoundException { //me lo ha consigliato di aggungere eclipse, not sure cosa faccia
		FileInputStream fileCodiciFiscali = new FileInputStream (path + "\\" + nomeCodici);
		XMLStreamReader xmlr = inizializzaReader(path, fileCodiciFiscali);
		while (xmlr.hasNext()) {
			switch (xmlr.getEventType()) {
			case XMLStreamConstants.CHARACTERS:
					this.listaCodici.add(xmlr.getText());
				break;
			default:
				break;
			}
			xmlr.next();
		}
		xmlr.close();
	}
	
	private void leggiListaComuni () throws XMLStreamException, FileNotFoundException {
		FileInputStream fileComuni = new FileInputStream (path + "\\" + nomeComuni);
		XMLStreamReader xmlr = inizializzaReader(path, fileComuni);
		String nome = null, codice = null;
		while (xmlr.hasNext()) {
			switch (xmlr.getEventType()) {
				case  XMLStreamConstants.START_ELEMENT:
					switch (xmlr.getAttributeLocalName(0)) {
					case "nome":
						xmlr.next();
						nome = xmlr.getText();
						break;
					case "cognome":
						xmlr.next();
						codice = xmlr.getText();
						break;
					default:
						break;
						}
				case  XMLStreamConstants.END_ELEMENT:
					if (xmlr.getAttributeLocalName(0).equals("Comune")) {
						this.listaComuni.add(new Comune(nome,codice));
					}
					break;
				default:
					break;
			}
			xmlr.next();
		}
		xmlr.close();
	}
	
	private void leggiListaPersone () throws XMLStreamException, FileNotFoundException {
		FileInputStream filePersone = new FileInputStream (path + "\\" + nomePersone);
		XMLStreamReader xmlr = inizializzaReader(path, filePersone);
		try {
		aggiornaListaPersone(xmlr);
		}
		catch (Exception e) {
			System.out.println("Errore nella lettura del file");
		}
		xmlr.close();
	}

	private void aggiornaListaPersone(XMLStreamReader xmlr) throws XMLStreamException {
		String nome = null;
		String cognome = null;
		String dataNascita = null;
		String comuneNascita = null;
		char sesso = 0;
		while (xmlr.hasNext()) {
			switch (xmlr.getEventType()) {
				case  XMLStreamConstants.START_ELEMENT:
					switch (xmlr.getAttributeLocalName(0)) {
					case "nome":
						xmlr.next();
						nome = xmlr.getText();
						break;
					case "cognome":
						xmlr.next();
						cognome = xmlr.getText();
						break;
					case "comune_nascita":
						xmlr.next();
						comuneNascita = xmlr.getText();
						break;
					case "data_nascita":
						xmlr.next();
						dataNascita = xmlr.getText();
						break;
					case "sesso":
						xmlr.next();
						sesso = xmlr.getText().charAt(0);
						break;
					default:
						break;
					}
				case  XMLStreamConstants.END_ELEMENT:
					if (xmlr.getAttributeLocalName(0).equals("Persona")) this.listaPersone.add(new Persona(nome, cognome, sesso, comuneNascita, dataNascita));
					break;
				default:
					break;
			}
			xmlr.next();
		}
	}
}
