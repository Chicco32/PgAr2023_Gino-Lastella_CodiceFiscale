package it.unibs.arnaldo.CodiceFiscale;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.xml.stream.XMLStreamException;

public class MainTestCodici {

	public static void main(String[] args) throws FileNotFoundException, XMLStreamException {
		ArrayList<String> codiciprova = new ArrayList<>();
		ArrayList<Comune> comuniprova = new ArrayList<>();
		IOStream ios = new IOStream();
		codiciprova = ios.getListaCodici();
		for (int i=0; i<7; i++) {
			System.out.println(codiciprova.get(i));
		}
		comuniprova = ios.getListaComuni();
		for (int i=0; i<7; i++) {
			System.out.println(comuniprova.get(i).toString());
		}
	}

}
