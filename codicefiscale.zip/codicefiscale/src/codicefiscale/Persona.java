package codicefiscale;

import java.util.Date;

public class Persona {
	
	private String nome;
	private String cognome;
	private char sesso;
	private Comune comune;
	private Date dataNascita;
	private String codiceFiscale;
	
	Persona(String nome,String cognome,char sesso,Comune comune,Date dataNascita,String codiceFiscale){
		
		this.nome = nome;
		this.cognome = cognome;
		this.sesso = sesso;
		this.comune = comune;
		this.dataNascita = dataNascita;
		this.codiceFiscale = codiceFiscale;
	}

	public String getNome() {
		return nome;
	}
	public String getCognome() {
		return cognome;
	}
	public char getSesso() {
		return sesso;
	}
	public Comune getComune() {
		return comune;
	}
	public Date getDataNascita() {
		return dataNascita;
	}
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	public String toString () {
		String stringa = this.nome + "\n" + this.cognome + "\n" + this.sesso + "\n" + this.comune + "\n" + this.dataNascita + "\n" + this.codiceFiscale;
		return stringa;
	}
}
