package codicefiscale;

public class Comune {
	
	private String nome;
	private String codiceId;
	
	Comune (String nome,String codiceId) {
		
		this.nome = nome;
		this.codiceId = codiceId;
	}
	
	public String getNome () {
		return nome;
	}
	
	public String getCodiceId () {
		return codiceId;
	}
	
	public String toString () {
		String stringa = this.nome + "\n" + this.codiceId;
		return stringa;
	}
}
